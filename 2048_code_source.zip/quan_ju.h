#pragma once
//c
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<stdbool.h>
#include<assert.h>
#include<math.h>
#include<Windows.h>
#include<stddef.h>
#include<conio.h>

//c++
#include<string>
#include<iostream>
#include<vector>
using namespace std;


int wan_jia[4][4];